﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Prime31;

namespace Postie.Scripts.LeaderboardRelated
{
    public class LeaderboardManagerIOS : MonoBehaviour
    {
        #if UNITY_IOS
        public static LeaderboardManagerIOS Instance;

        private AuthenticateFrom authenticateFrom;
        private long score;

        public static string leaderboardID = "postie.bestscore";

        void Awake()
        {
            Instance = this;
            GameCenterManager.playerAuthenticatedEvent += () =>
            {
                Debug.Log("Player authenticated");
            };
            GameCenterManager.playerFailedToAuthenticateEvent += (obj) =>
            {
                Debug.Log("Player failed to authenticate");
            };
        }

        void Start()
        {
            CheckIfAuthenticated();
        }

        public void ShowLeaderboard()
        {
            Debug.Log(System.Reflection.MethodBase.GetCurrentMethod().Name);
            authenticateFrom = AuthenticateFrom.ShowLeaderboard;
            CheckIfAuthenticated();
        }

        private void LeaderboardShow()
        {
            GameCenterBinding.showLeaderboardWithTimeScopeAndLeaderboard(GameCenterLeaderboardTimeScope.AllTime, leaderboardID); 
        }

        public void SubmitScore(int score)
        {
            Debug.Log(System.Reflection.MethodBase.GetCurrentMethod().Name);
            this.score = score;
            authenticateFrom = AuthenticateFrom.SubmitScore;
            CheckIfAuthenticated();
        }

        private void ScoreSubmit()
        {
            GameCenterBinding.reportScore((long)score, leaderboardID);
        }

        public void CheckIfAuthenticated()
        {
            if (!GameCenterBinding.isPlayerAuthenticated())
            {
                GameCenterBinding.authenticateLocalPlayer(true);
            }
            else
            {
                Authenticated();
            }
        }

        private void Authenticated()
        {
            switch (authenticateFrom)
            {
                case AuthenticateFrom.ShowLeaderboard:
                    LeaderboardShow();
                    break;

                case AuthenticateFrom.SubmitScore:
                    ScoreSubmit();
                    break;
            }
        }
        #endif
    }

    public enum AuthenticateFrom
    {
        SubmitScore,
        ShowLeaderboard
    }
}
